﻿using DatabaseServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
//using System.ServiceModel;

namespace Console_For_My_Library
{
    public class Program
    {
        static void Main(string[] args)
        {

            /*
            using (ServiceHost host = new ServiceHost(typeof(DatabaseService)))
            {
                host.Open();
                Console.WriteLine("Service is running...");
                Console.WriteLine("Press Enter to terminate the service.");
                Console.ReadLine();
            }*/

        }
    }
}
