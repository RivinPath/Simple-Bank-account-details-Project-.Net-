﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace BusinessTier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /**/


            Console.WriteLine("Starting the Business Tier Service...");

           
            ServiceHost host = new ServiceHost(typeof(BusinessServer));

            
            NetTcpBinding tcpBinding = new NetTcpBinding();

            
            host.AddServiceEndpoint(typeof(IBusinessServerInterface), tcpBinding, "net.tcp://0.0.0.0:8200/BusinessService");

            
            host.Open();
            Console.WriteLine("Business Tier Service is Online.");
            Console.ReadLine();

            
            host.Close();   

        }
    }
}
