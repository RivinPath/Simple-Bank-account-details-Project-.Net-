﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using DatabaseServer;
using System.Runtime.CompilerServices;

namespace BusinessTier
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    internal class BusinessServer : IBusinessServerInterface
    {
        private const string DataTierUrl = "net.tcp://localhost:8100/DataService";
        private uint LogNumber = 0;

        public int GetNumEntries()
        {
            using (ChannelFactory<IDatabaseService> channelFactory = new ChannelFactory<IDatabaseService>(new NetTcpBinding(), DataTierUrl))
            {
                IDatabaseService dataServer = channelFactory.CreateChannel();


                //Logging
                
                Log("Getting the number of entries from the Data tier.");
                Log($"GetNumEntries called. Returned: {dataServer.GetNumEntries()}");

                return dataServer.GetNumEntries();
            }
        }

        public void GetValuesForEntry(int index, out uint acctNo, out uint pin, out int bal, out string fName, out string lName)
        {
            using (ChannelFactory<IDatabaseService> channelFactory = new ChannelFactory<IDatabaseService>(new NetTcpBinding(), DataTierUrl))
            {
                IDatabaseService dataServer = channelFactory.CreateChannel();

                

                Log($"Getting the values of entries from the Data tier for the index: {index}");
                



                dataServer.GetValuesForEntry(index, out acctNo, out pin, out bal, out fName, out lName);
            }
        }

        public bool SearchByLastName(string lastName, out uint acctNo, out uint pin, out int bal, out string fName, out string lName)
        {
            using (ChannelFactory<IDatabaseService> channelFactory = new ChannelFactory<IDatabaseService>(new NetTcpBinding(), DataTierUrl))
            {
                IDatabaseService dataServer = channelFactory.CreateChannel();
                int numEntries = dataServer.GetNumEntries();

                for (int i = 0; i < numEntries; i++)
                {
                    dataServer.GetValuesForEntry(i, out acctNo, out pin, out bal, out fName, out lName);
                    if (lName.Equals(lastName, StringComparison.OrdinalIgnoreCase))
                    {

                        //Logging
                        Log("Found the given Last Name, Yeah!!");
                        Log($"Search result for last name '{lastName}': AcctNo={acctNo}, PIN={pin}, Balance={bal}, FirstName={fName}, LastName={lName}");

                        return true;
                    }
                }


                
                

                acctNo = pin = 0;
                bal = 0;
                fName = lName = string.Empty;

               


                return false;
            }
        }


        [MethodImpl(MethodImplOptions.Synchronized)] 
        private void Log(string logString)
        {
            LogNumber++;
            Console.WriteLine($"Log #{LogNumber}: {logString}");
        }


        

    }
}
