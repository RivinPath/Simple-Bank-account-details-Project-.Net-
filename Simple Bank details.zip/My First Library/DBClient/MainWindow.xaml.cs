﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using DatabaseServer;
using System.Net.NetworkInformation;
using System.Windows.Interop;
using BusinessTier;

namespace DBClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public delegate bool SearchDelegate(string lastName, out uint acctNo, out uint pin, out int bal, out string fName, out string lName);
    public partial class MainWindow : Window
    {
        private IDatabaseService DSfoob;
        private IBusinessServerInterface foob;
        public MainWindow()
        {
            InitializeComponent();





            ChannelFactory<IBusinessServerInterface> foobFactory;
            NetTcpBinding tcp = new NetTcpBinding();
            

            


            ChannelFactory<IBusinessServerInterface> channelFactory;
            NetTcpBinding tcpBinding = new NetTcpBinding();
            string URL = "net.tcp://localhost:8200/BusinessService";
            channelFactory = new ChannelFactory<IBusinessServerInterface>(tcpBinding, URL);

            
            foob = channelFactory.CreateChannel();


            
            


            theLabel.Content = "Total Items: " + foob.GetNumEntries().ToString();

        }

        

        private async void IndexButton_OnClick(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(IndexBox.Text, out var index))
            {
                LoadData(index);
            }
            else
            {
                MessageBox.Show($"\"{IndexBox.Text}\" is not a valid integer...");
            }

            


        }

        private void LoadData(int index)
        {
            
            
                foob.GetValuesForEntry(index, out var accNo, out var pin, out var bal, out var fName, out var lName);
                first_Name.Text = fName;
                lastName.Text = lName;
                balance.Text = bal.ToString("C");
                accountNumber.Text = accNo.ToString();
                pinTextBox.Text = pin.ToString("D4");
                
            
        }

        private async void searchButton_OnClick(object sender, RoutedEventArgs e)
        {

            


            string searchLastName = lastNameTextBox.Text;

            
            SetUiForLoading(true);

            try
            {
                
                await Task.Run(() =>
                {
                    uint acctNo, pin;
                    int balanceValue; 
                    string firstNameValue, lastNameValue; 

                    
                    foob.SearchByLastName(searchLastName, out acctNo, out pin, out balanceValue, out firstNameValue, out lastNameValue);

                    
                    Dispatcher.Invoke(() =>
                    {
                        accountNumber.Text = acctNo.ToString();
                        pinTextBox.Text = pin.ToString("D4");
                        balance.Text = balanceValue.ToString("C"); 
                        first_Name.Text = firstNameValue; 
                        lastName.Text = lastNameValue; 
                    });
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                
                SetUiForLoading(false);
            }

        }


        private void SearchCompleted(IAsyncResult ar)
        {
            var searchDelegate = (SearchDelegate)ar.AsyncState;

            bool found = searchDelegate.EndInvoke(out uint acctNo, out uint pin, out int bal, out string fName, out string lName, ar);

            
            Dispatcher.Invoke(() =>
            {
                searchButton.IsEnabled = true;
                goButton.IsEnabled = true;
                first_Name.IsReadOnly = false;
                lastName.IsReadOnly = false;
                accountNumber.IsReadOnly = false;
                pinTextBox.IsReadOnly = false;
                balance.IsReadOnly = false;
                progressBar.IsIndeterminate = false;

                if (found)
                {
                    first_Name.Text = fName;
                    this.lastName.Text = lName;
                    balance.Text = bal.ToString("C");
                    accountNumber.Text = acctNo.ToString();
                    pinTextBox.Text = pin.ToString("D4");
                }
                else
                {
                    MessageBox.Show("No record found with that last name.");
                }
            });
        }



        private void SetUiForLoading(bool isLoading)
        {
            progressBar.Visibility = isLoading ? Visibility.Visible : Visibility.Hidden;
            progressBar.IsIndeterminate = isLoading;

            
            searchButton.IsEnabled = !isLoading;
            lastName.IsReadOnly = isLoading;
            first_Name.IsReadOnly = isLoading;
            accountNumber.IsReadOnly = isLoading;
            pinTextBox.IsReadOnly = isLoading;
            balance.IsReadOnly = isLoading;
        }
    }
}
