﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_First_Library
{
    public class DatabaseClass
    {

        /**/
        private List<DataStruct> dataStruct;  

        
        public DatabaseClass()
        {
            dataStruct = new List<DataStruct>();
            DatabaseGenerator generator = new DatabaseGenerator();

            
            for (int i = 0; i < 100000; i++)
            {
                DataStruct record = new DataStruct();
                generator.GetNextAccount(out record.pin, out record.acctNo, out record.firstName, out record.lastName, out record.balance);
                dataStruct.Add(record);
            }
        }

        
        public uint GetAcctNoByIndex(int index)
        {
            if (index >= 0 && index < dataStruct.Count)
            {
                return dataStruct[index].acctNo;
            }
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        
        public uint GetPINByIndex(int index)
        {
            if (index >= 0 && index < dataStruct.Count)
            {
                return dataStruct[index].pin;
            }
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        
        public string GetFirstNameByIndex(int index)
        {
            if (index >= 0 && index < dataStruct.Count)
            {
                return dataStruct[index].firstName;
            }
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        
        public string GetLastNameByIndex(int index)
        {
            if (index >= 0 && index < dataStruct.Count)
            {
                return dataStruct[index].lastName;
            }
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        
        public int GetBalanceByIndex(int index)
        {
            if (index >= 0 && index < dataStruct.Count)
            {
                return dataStruct[index].balance;
            }
            throw new IndexOutOfRangeException("Index is out of range.");
        }

        
        public int GetNumRecords()
        {
            return dataStruct.Count;
        }

    }
}
