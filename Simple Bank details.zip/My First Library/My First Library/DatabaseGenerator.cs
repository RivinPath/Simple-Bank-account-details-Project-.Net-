﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_First_Library
{
    internal class DatabaseGenerator
    {

        /**/
        private static readonly Random random = new Random();

        
        private string GetFirstname()
        {
            string[] firstNames = { "John", "Jane", "Michael", "Emily", "David", "Sarah", "Robert", "Jessica","Rivin", "Wednesday", "Mulan", "Hannah", "Aurora", "Henry", "Brandon", "Indra" };
            return firstNames[random.Next(firstNames.Length)];
        }

        
        private string GetLastname()
        {
            string[] lastNames = { "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Addams", "Rajputh", "Rutherford", "Bloodsworth" };
            return lastNames[random.Next(lastNames.Length)];
        }

        
        private uint GetPIN()
        {
            return (uint)random.Next(1000, 9999);
        }

        
        private uint GetAcctNo()
        {
            return (uint)random.Next(10000000, 99999999);
        }

        
        private int GetBalance()
        {
            return random.Next(-5000, 50000); // Balance can range from -5000 to 50000
        }

        
        public void GetNextAccount(out uint pin, out uint acctNo, out string firstName, out string lastName, out int balance)
        {
            pin = GetPIN();
            acctNo = GetAcctNo();
            firstName = GetFirstname();
            lastName = GetLastname();
            balance = GetBalance();
        }

    }
}
