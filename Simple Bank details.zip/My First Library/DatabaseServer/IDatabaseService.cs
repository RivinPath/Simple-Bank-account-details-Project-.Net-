﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
//using My_First_Library;

namespace DatabaseServer
{

    [ServiceContract]
    public interface IDatabaseService
    {

        /**/

        
        [OperationContract]
        int GetNumEntries();

        
        [OperationContract]
        void GetValuesForEntry(int index, out uint acctNo, out uint pin, out int bal, out string fName, out string lName);

    }
}
