﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using My_First_Library;

namespace DatabaseServer
{
    
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    internal class DatabaseService : IDatabaseService
    {

        /**/

        private DatabaseClass _database;

        
        public DatabaseService()
        {
            _database = new DatabaseClass();
        }

        
        public int GetNumEntries()
        {
            return _database.GetNumRecords();
        }

        
        public void GetValuesForEntry(int index, out uint acctNo, out uint pin, out int bal, out string fName, out string lName)
        {
            acctNo = _database.GetAcctNoByIndex(index);
            pin = _database.GetPINByIndex(index);
            bal = _database.GetBalanceByIndex(index);
            fName = _database.GetFirstNameByIndex(index);
            lName = _database.GetLastNameByIndex(index);
        }
    }
}
